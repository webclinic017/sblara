
Use it as shortcode.
Example:
[mdf_chain_menu post_slug='product' taxonomy='product_cat' term_id=0 exclude='36,12' show_count=1 button_title='Watch It' target='_blank']
Attributes:
* post_slug - which post slug to use in chain menu. Default is 'post'
* taxonomy - taxonomy which terms show. Default is 'category'
* term_id - start term ID. 0 means all
* exlude - which terms hide. Use comma
* show_count - show count of posts in term. Default is 0
* button_title - title for button with link of selected post. By default is 'GO!'
* target - how to open selected post. Default is 'self'

